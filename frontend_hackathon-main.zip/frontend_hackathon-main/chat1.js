// chat.js
const API_BASE = "http://127.0.0.1:5000";

let token = null;
try { token = localStorage.getItem("token") || null; } catch (e) {}

const chatLogEl = document.getElementById("chat-log");
const inputEl = document.getElementById("chat-input");
const sendBtn = document.getElementById("send-btn");
const loginWarning = document.getElementById("login-warning");

function setEnabled(enabled) {
  inputEl.disabled = !enabled;
  sendBtn.disabled = !enabled;
}

if (!token) {
  loginWarning.style.display = "block";
  setEnabled(false);
} else {
  loginWarning.style.display = "none";
  setEnabled(true);
}

function appendMessage(role, text) {
  const div = document.createElement("div");
  div.className = "msg " + (role === "user" ? "user" : "ai");
  div.textContent = text;
  chatLogEl.appendChild(div);
  chatLogEl.scrollTop = chatLogEl.scrollHeight;
}

async function sendChat(message, subject = "") {
  const body = { message, subject, history: collectHistory() };
  const res = await fetch(API_BASE + "/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { "Authorization": "Bearer " + token } : {})
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `API error: ${res.status}`);
  }
  return res.json();
}

function collectHistory() {
  const nodes = chatLogEl.querySelectorAll(".msg");
  const history = [];
  nodes.forEach(n => {
    if (n.classList.contains("user")) {
      history.push({ role: "user", content: n.textContent });
    } else {
      history.push({ role: "assistant", content: n.textContent });
    }
  });
  return history.slice(-20); // keep last 20 turns
}

sendBtn.addEventListener("click", async () => {
  const text = (inputEl.value || "").trim();
  if (!text || !token) return;

  appendMessage("user", text);
  inputEl.value = "";
  setEnabled(false);
  try {
    const data = await sendChat(text, "");
    appendMessage("assistant", data.reply);
  } catch (e) {
    appendMessage("assistant", "⚠️ " + e.message);
  } finally {
    setEnabled(true);
    inputEl.focus();
  }
});

inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendBtn.click();
  }
});
