const API_BASE = "http://127.0.0.1:5000";
let token = null;

// Generic API fetch
async function apiFetch(path, options = {}) {
  if (!options.headers) options.headers = {};
  if (token) options.headers["Authorization"] = "Bearer " + token;
  if (!options.headers["Content-Type"] && !(options.body instanceof FormData)) {
    options.headers["Content-Type"] = "application/json";
  }
  const res = await fetch(API_BASE + path, options);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// Navigation
document.getElementById("nav-auth").addEventListener("click", () => showSection("auth-section"));
document.getElementById("nav-quiz").addEventListener("click", () => showSection("quiz-section"));
document.getElementById("nav-lesson").addEventListener("click", () => showSection("lesson-section"));
document.getElementById("nav-gamification").addEventListener("click", () => showSection("gamification-section"));
document.getElementById("nav-chatbot").addEventListener("click", () => {
  window.location.href = "chat.html";
});

function showSection(id) {
  document.querySelectorAll("main section").forEach(sec => sec.style.display = "none");
  document.getElementById(id).style.display = "block";
}

// Auth
document.getElementById("register-btn").addEventListener("click", async () => {
  try {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const email = document.getElementById("email").value;
    await apiFetch("/register", {
      method: "POST",
      body: JSON.stringify({ username, password, email })
    });
    alert("Registered! Now log in.");
  } catch (e) {
    alert(e.message);
  }
});

document.getElementById("login-btn").addEventListener("click", async () => {
  try {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const data = await apiFetch("/login", {
      method: "POST",
      body: JSON.stringify({ username, password })
    });
    token = data.token;
    alert("Logged in!");
    showSection("lesson-section");
    document.getElementById("quiz-section").style.display = "block";
    document.getElementById("gamification-section").style.display = "block";
  } catch (e) {
    alert(e.message);
  }
});

// Initial learning style quiz
document.getElementById("quiz-submit-btn").addEventListener("click", async () => {
  try {
    const q1 = document.getElementById("q1").value;
    const data = await apiFetch("/quiz/initial", {
      method: "POST",
      body: JSON.stringify({ answers: { q1 } })
    });
    alert(`Detected style: ${data.style} (confidence ${Math.round(data.confidence * 100)}%)`);
  } catch (e) {
    alert(e.message);
  }
});

// =======================
// Topic-based AI Test
// =======================
let testQuestions = [];
let currentQ = 0;
let userAnswers = [];

document.getElementById('start-test').addEventListener('click', async () => {
  const topic = document.getElementById('topic-input').value.trim();
  if (!topic) {
    alert("Please enter a topic!");
    return;
  }

  try {
    const data = await apiFetch("/start-test", {
      method: "POST",
      body: JSON.stringify({ topic, num_questions: 10 })
    });

    if (data.questions && data.questions.length > 0) {
      testQuestions = data.questions;
      currentQ = 0;
      userAnswers = [];
      showTestQuestion(currentQ);
    } else {
      alert("No questions returned from AI.");
    }
  } catch (e) {
    alert("Error fetching AI questions: " + e.message);
  }
});

function showTestQuestion(index) {
  const container = document.getElementById('quiz-container');
  container.innerHTML = "";

  if (index >= testQuestions.length) {
    let score = 0;
    testQuestions.forEach((q, i) => {
      if (userAnswers[i] === q.answer) score++;
    });
    container.innerHTML = `<h3>Test Completed!</h3>
      <p>Your score: ${score} / ${testQuestions.length}</p>`;
    return;
  }

  const q = testQuestions[index];
  let html = `<p>Q${index+1}: ${q.question}</p>`;
  q.options.forEach(opt => {
    html += `<div class="option" data-value="${opt}">${opt}</div>`;
  });
  html += `<button id="next-btn">Next</button>`;
  container.innerHTML = html;

  // Option click handler
  document.querySelectorAll('.option').forEach(option => {
    option.addEventListener('click', () => {
      userAnswers[index] = option.dataset.value;
      // highlight selection
      document.querySelectorAll('.option').forEach(o => o.style.backgroundColor = '');
      option.style.backgroundColor = '#d0f0c0';
    });
  });

  document.getElementById('next-btn').addEventListener('click', () => {
    if (!userAnswers[index]) {
      alert("Please select an option before proceeding.");
      return;
    }
    showTestQuestion(index + 1);
  });
}

// =======================
// Lesson generation
// =======================
function displayLesson(text) {
  const outputDiv = document.getElementById("lesson-output");
  let html = text
    .replace(/^#{1,6}\s*/gim, '') // remove markdown headings
    .replace(/\*\*(.*?)\*\*/gim, '<b>$1</b>') // bold
    .replace(/^\s*[-*]\s+(.*)/gim, '<li>$1</li>') // bullets
    .replace(/(<li>.*<\/li>)/gims, '<ul>$1</ul>'); // wrap bullets in ul
  outputDiv.innerHTML = html.trim();
}

document.getElementById("lesson-generate-btn").addEventListener("click", async () => {
  try {
    const topic = document.getElementById("topic").value;
    const difficulty = document.getElementById("difficulty").value;
    const length = document.getElementById("length").value;
    const data = await apiFetch("/lesson/generate", {
      method: "POST",
      body: JSON.stringify({ topic, difficulty, length })
    });
    displayLesson(data.lesson);
    document.getElementById("read-lesson-btn").style.display = "inline-block";
  } catch (e) {
    alert(e.message);
  }
});

// Text-to-Speech
document.getElementById("read-lesson-btn").addEventListener("click", () => {
  const textContent = document.getElementById("lesson-output").innerText.trim();
  if (!textContent) {
    alert("No lesson text to read.");
    return;
  }
  const utterance = new SpeechSynthesisUtterance(textContent);
  utterance.lang = "en-US";
  speechSynthesis.cancel();
  speechSynthesis.speak(utterance);
});

// Gamification
document.getElementById("refresh-gamification-btn").addEventListener("click", async () => {
  try {
    const data = await apiFetch("/gamification", { method: "GET" });
    document.getElementById("gamification-output").innerHTML =
      `<p><b>Points:</b> ${data.points}</p>
       <p><b>Streak:</b> ${data.streak}</p>
       <p><b>Badges:</b> ${data.badges.join(", ")}</p>`;
  } catch (e) {
    alert(e.message);
  }
});
