# app.py
import os
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, g
from flask_migrate import Migrate
from flask_cors import CORS

from models import db, User, Profile, Progress, Gamification, SpacedItem
import detection
import ai_client
import utils

from utils import create_token, decode_token, hash_password, verify_password

# -------- Initialize Flask --------
app = Flask(__name__)
CORS(app)  # This allows all origins by default

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///ai_tutor.db")
app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)
migrate = Migrate(app, db)

# -------- Serve frontend --------
@app.route("/")
def index():
    return app.send_static_file("index3.html")  # index3.html goes in /static folder

# -------- helpers ----------
def auth_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing token"}), 401
        token = auth.split(" ", 1)[1]
        user_id = decode_token(token)
        if not user_id:
            return jsonify({"error": "Invalid token"}), 401
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        g.user = user
        return fn(*args, **kwargs)
    return wrapper

# -------- endpoints ----------
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})

# ... [all your existing endpoints remain unchanged] ...

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=int(os.getenv("PORT","5000")))
