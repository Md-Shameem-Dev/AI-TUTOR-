# detection.py
"""
Simple modular learning-style detector.
- initial_quiz(answers): returns style + confidence
- update_style_with_behavior(old_style, behavior_data): refines style progressively
"""

from collections import Counter

STYLES = ["visual", "auditory", "kinesthetic", "reading", "blended"]

def initial_quiz(answers):
    """
    answers: dict of question_id -> answer_tag
    Each answer_tag maps to one or more styles.
    For demo, we expect answers with tags matching STYLES or lists.
    """
    # map answer tags -> style votes
    votes = Counter()
    for q, a in answers.items():
        if isinstance(a, list):
            for tag in a:
                if tag in STYLES:
                    votes[tag] += 1
        else:
            if a in STYLES:
                votes[a] += 1

    if not votes:
        return {"style": "unknown", "confidence": 0.0}

    top = votes.most_common()
    if len(top) == 1 or top[0][1] > top[1][1]:
        style = top[0][0]
        confidence = min(0.95, 0.5 + top[0][1] * 0.1)
    else:
        # blended if close tie
        style = "blended"
        confidence = 0.5

    return {"style": style, "confidence": confidence}


def update_style_with_behavior(current_style, behavior):
    """
    behavior: dict of metrics e.g.
      {
        "avg_time_on_text": seconds,
        "avg_video_watch_pct": 0.6,
        "interactive_clicks": 12,
        "audio_playbacks": 7,
        "quiz_accuracy_on_visual": 0.8,
        "quiz_accuracy_on_audio": 0.6
      }
    Returns refined (style, confidence)
    """
    scores = {s: 0.0 for s in STYLES}
    # heuristics (simple)
    if behavior.get("avg_video_watch_pct", 0) > 0.5:
        scores["visual"] += 2
    if behavior.get("audio_playbacks", 0) > 3:
        scores["auditory"] += 2
    if behavior.get("interactive_clicks", 0) > 5:
        scores["kinesthetic"] += 2
    if behavior.get("avg_time_on_text", 0) > 30:
        scores["reading"] += 2

    # accuracy signals
    if behavior.get("quiz_accuracy_on_visual", 0) > 0.75:
        scores["visual"] += 1.5
    if behavior.get("quiz_accuracy_on_audio", 0) > 0.75:
        scores["auditory"] += 1.5

    # baseline from current style
    if current_style in scores and current_style != "unknown":
        scores[current_style] += 1

    # pick top
    top_style = max(scores, key=lambda k: scores[k])
    top_score = scores[top_style]
    total = sum(scores.values()) or 1.0
    confidence = min(0.99, 0.3 + (top_score / total))

    if top_score < 1:  # no clear signal
        return {"style": current_style or "unknown", "confidence": 0.3}

    # if close between top two -> blended
    sorted_scores = sorted(scores.values(), reverse=True)
    if len(sorted_scores) > 1 and (sorted_scores[0] - sorted_scores[1]) < 0.5:
        return {"style": "blended", "confidence": confidence * 0.8}
    else:
        return {"style": top_style, "confidence": confidence}
