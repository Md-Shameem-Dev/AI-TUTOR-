# app.py
import os
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, g
from flask_migrate import Migrate
from flask_cors import CORS
import requests

from models import db, User, Profile, Progress, Gamification, SpacedItem
import detection
import ai_client
import utils
from utils import create_token, decode_token, hash_password, verify_password

app = Flask(__name__, static_folder="static", static_url_path="/")
CORS(app)  # Allow all origins by default

# ---------- Config ----------
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///ai_tutor.db")
app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Azure config via env vars (no secrets hardcoded)
AZURE_BASE = os.getenv("AZURE_BASE", "https://kaalan007010-5667-resource.services.ai.azure.com")
AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT", "phi-4-mini-instruct")
AZURE_API_VERSION = os.getenv("AZURE_API_VERSION", "2024-05-01-preview")
AZURE_API_KEY = os.getenv("AZURE_API_KEY")  # REQUIRED

db.init_app(app)
migrate = Migrate(app, db)

# ---------- Static ----------
@app.route("/")
def index():
    # Serve main UI
    return app.send_static_file("index.html")

# Optional: direct route to chat UI
@app.route("/chatbot")
def chatbot():
    return app.send_static_file("chat.html")

# ---------- Auth helper ----------
def auth_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing token"}), 401
        token = auth.split(" ", 1)[1]
        user_id = decode_token(token)
        if not user_id:
            return jsonify({"error": "Invalid token"}), 401
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        g.user = user
        return fn(*args, **kwargs)
    return wrapper

# ---------- Health ----------
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})

# ---------- Auth ----------
@app.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    email = data.get("email")
    if not username or not password:
        return jsonify({"error": "username and password required"}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"error": "username exists"}), 400
    user = User(username=username, password_hash=hash_password(password), email=email)
    db.session.add(user)
    db.session.commit()
    # create profile & gamification row
    profile = Profile(user_id=user.id, learning_style="unknown", interests="")
    gam = Gamification(user_id=user.id)
    db.session.add(profile)
    db.session.add(gam)
    db.session.commit()
    return jsonify({"message": "registered", "user_id": user.id})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    if not username or not password:
        return jsonify({"error": "username and password required"}), 400
    user = User.query.filter_by(username=username).first()
    if not user or not verify_password(password, user.password_hash):
        return jsonify({"error": "invalid credentials"}), 401
    token = create_token(user.id)
    return jsonify({"token": token, "user_id": user.id})

# ---------- Learning Style ----------
@app.route("/quiz/initial", methods=["POST"])
@auth_required
def initial_quiz():
    payload = request.get_json() or {}
    answers = payload.get("answers", {})
    res = detection.initial_quiz(answers)
    # update profile
    profile = g.user.profile
    profile.learning_style = res["style"]
    profile.detection_confidence = res["confidence"]
    db.session.commit()
    return jsonify({"style": res["style"], "confidence": res["confidence"]})

@app.route("/behavior/update", methods=["POST"])
@auth_required
def update_behavior():
    payload = request.get_json() or {}
    behavior = payload.get("behavior", {})
    profile = g.user.profile
    old_style = profile.learning_style
    res = detection.update_style_with_behavior(old_style, behavior)
    profile.learning_style = res["style"]
    profile.detection_confidence = res["confidence"]
    db.session.commit()
    return jsonify({"style": res["style"], "confidence": res["confidence"]})

# ---------- Lessons ----------
@app.route("/lesson/generate", methods=["POST"])
@auth_required
def generate_lesson():
    payload = request.get_json() or {}
    topic = payload.get("topic")
    length = payload.get("length", "short")  # short/medium/long
    difficulty = payload.get("difficulty", "beginner")
    # fetch user profile
    profile = g.user.profile
    style = profile.learning_style or "general"
    interests = profile.interests or ""
    provider = payload.get("provider", "azure")  # allow override

    if not topic:
        return jsonify({"error": "topic required"}), 400

    prompt = (
        f"Create a lesson on '{topic}' for a {style} learner. "
        f"Difficulty: {difficulty}. Length: {length}. "
        f"Include:\n"
        "- A short learning objective\n"
        "- 3 activities tailored to the learner style (one should be interactive)\n"
        "- A short quiz with answers\n"
        "- Suggestions for spaced repetition items and a short summary\n"
    )
    if interests:
        prompt += f"\nUse examples related to: {interests}."

    try:
        lesson_text = ai_client.generate_lesson(prompt, provider=provider)
    except Exception as e:
        return jsonify({"error": "AI generation failed", "details": str(e)}), 500

    # Save a Progress entry stub
    progress = Progress(
        user_id=g.user.id,
        lesson_id=f"{topic}-{datetime.utcnow().timestamp()}",
        status="in_progress"
    )
    db.session.add(progress)
    db.session.commit()

    # Gamification: award points for generating lesson
    gam = g.user.gamification
    gam.points += 5
    db.session.commit()

    return jsonify({"lesson": lesson_text, "progress_id": progress.id, "awarded_points": 5})

# ---------- Progress ----------
@app.route("/progress/report", methods=["POST"])
@auth_required
def report_progress():
    payload = request.get_json() or {}
    progress_id = payload.get("progress_id")
    status = payload.get("status", "complete")
    accuracy = float(payload.get("accuracy", 0.0) or 0.0)
    time_spent = int(payload.get("time_spent_seconds", 0) or 0)
    behavior = payload.get("behavior", {})

    progress = Progress.query.get(progress_id)
    if not progress or progress.user_id != g.user.id:
        return jsonify({"error": "progress not found"}), 404

    progress.status = status
    progress.accuracy = accuracy
    progress.time_spent_seconds = time_spent
    progress.last_interaction = datetime.utcnow()
    db.session.commit()

    # Spaced repetition
    spaced = payload.get("spaced_items", [])
    for item in spaced:
        si = SpacedItem.query.filter_by(
            user_id=g.user.id, content_id=item['content_id']
        ).first()
        if not si:
            si = SpacedItem(
                user_id=g.user.id,
                content_id=item['content_id'],
                interval_days=1,
                repetition=0,
                easiness=2.5,
                last_reviewed=datetime.utcnow(),
                due_date=datetime.utcnow()
            )
            db.session.add(si)
        from utils import update_sm2
        local = {
            "repetition": si.repetition,
            "easiness": si.easiness,
            "interval_days": si.interval_days
        }
        updated = update_sm2(local, int(item.get("quality", 5)))
        si.repetition = updated['repetition']
        si.easiness = updated['easiness']
        si.interval_days = updated['interval_days']
        si.last_reviewed = datetime.utcnow()
        si.due_date = datetime.utcnow() + timedelta(days=si.interval_days)

    # Update behavior -> learning style
    profile = g.user.profile
    det = detection.update_style_with_behavior(profile.learning_style, behavior)
    profile.learning_style = det["style"]
    profile.detection_confidence = det["confidence"]

    # Gamification
    gam = g.user.gamification
    if status == "complete" and accuracy >= 0.7:
        gam.points += int(10 * accuracy)
        gam.streak += 1
    else:
        gam.streak = 0
    db.session.commit()

    return jsonify({
        "message": "progress saved",
        "new_style": profile.learning_style,
        "gamification": {"points": gam.points, "streak": gam.streak}
    })

# ---------- Spaced repetition ----------
@app.route("/spaced/due", methods=["GET"])
@auth_required
def spaced_due():
    now = datetime.utcnow()
    items = SpacedItem.query.filter(
        SpacedItem.user_id == g.user.id,
        SpacedItem.due_date <= now
    ).all()
    out = [
        {
            "content_id": i.content_id,
            "due_date": i.due_date.isoformat(),
            "repetition": i.repetition
        } for i in items
    ]
    return jsonify({"due": out})

# ---------- Gamification ----------
@app.route("/gamification", methods=["GET"])
@auth_required
def get_gamification():
    gam = g.user.gamification
    return jsonify({
        "points": gam.points,
        "streak": gam.streak,
        "badges": gam.badges.split(",") if gam.badges else []
    })

# ---------- Community ----------
@app.route("/community/match", methods=["GET"])
@auth_required
def community_match():
    profile = g.user.profile
    style = profile.learning_style or "unknown"
    matches = []
    if style != "unknown":
        q = Profile.query.filter(
            Profile.learning_style == style
        ).join(User).limit(20).all()
        matches = [
            {
                "user_id": p.user_id,
                "username": p.user.username,
                "confidence": p.detection_confidence
            }
            for p in q if p.user_id != g.user.id
        ]
    return jsonify({"matches": matches[:10]})

# ---------- Admin (dev) ----------
@app.route("/admin/users/<int:user_id>", methods=["GET"])
def admin_user(user_id):
    u = User.query.get(user_id)
    if not u:
        return jsonify({"error": "not found"}), 404
    return jsonify({
        "id": u.id, "username": u.username, "email": u.email,
        "learning_style": u.profile.learning_style if u.profile else None
    })

# ---------- AI Chatbot (CLEAN, SINGLE) ----------
@app.route("/chat", methods=["POST"])
def chat():
    """
    Accepts:
      { "message": "...", "style": "visual" } OR
      { "question": "...", "style": "visual" }

    Returns:
      { "answer": "..." }
    """
    if not AZURE_API_KEY:
        return jsonify({"answer": "Server missing AZURE_API_KEY env var."}), 500

    data = request.get_json() or {}
    user_text = (data.get("message") or data.get("question") or "").strip()
    style = data.get("style", "general")
    if not user_text:
        return jsonify({"answer": "Please provide a question or message."}), 400

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY
    }
    payload = {
        "messages": [
            {
                "role": "system",
                "content": f"You are a helpful AI tutor. Tailor your explanation for a {style} learner."
            },
            {"role": "user", "content": user_text}
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }

    try:
        url = f"{AZURE_BASE}/openai/deployments/{AZURE_DEPLOYMENT}/chat/completions?api-version={AZURE_API_VERSION}"
        resp = requests.post(url, headers=headers, json=payload, timeout=60)
        resp.raise_for_status()
        result = resp.json()
        answer = result["choices"][0]["message"]["content"]
        return jsonify({"answer": answer})
    except Exception as e:
        return jsonify({"answer": f"Error: {str(e)}"}), 500


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
