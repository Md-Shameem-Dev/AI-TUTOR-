# utils.py
import os, datetime
import jwt
from passlib.hash import bcrypt

JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")
JWT_ALGO = "HS256"
JWT_EXP_MINUTES = 60 * 24 * 7  # 7 days by default

def create_token(user_id):
    payload = {
        "user_id": user_id,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=JWT_EXP_MINUTES)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

def decode_token(token):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        return payload.get("user_id")
    except Exception:
        return None

def hash_password(password):
    return bcrypt.hash(password)

def verify_password(password, hash_):
    return bcrypt.verify(password, hash_)

# Simple SM-2 style spaced repetition update (very simplified)
def update_sm2(item, quality):
    # item: dict-like with keys 'repetition','easiness','interval_days'
    # quality: 0-5
    q = max(0, min(5, quality))
    if q < 3:
        item['repetition'] = 0
        item['interval_days'] = 1
    else:
        if item['repetition'] == 0:
            item['interval_days'] = 1
        elif item['repetition'] == 1:
            item['interval_days'] = 6
        else:
            item['interval_days'] = int(item['interval_days'] * item['easiness'])
        item['repetition'] += 1
    # update easiness
    item['easiness'] = max(1.3, item.get('easiness', 2.5) + 0.1 - (5 - q) * 0.08)
    return item
