# ai_client.py
import os
import requests

# -----------------------------
# Azure Phi-4-mini-instruct config
# -----------------------------
# Either set these as environment variables or hardcode them here
AZURE_BASE = os.getenv("AZURE_BASE", "https://kaalan007010-5667-resource.services.ai.azure.com")
DEPLOYMENT_NAME = os.getenv("DEPLOYMENT_NAME", "Phi-4-mini-instruct")
API_VERSION = os.getenv("API_VERSION", "2024-05-01-preview")
AZURE_API_KEY = os.getenv("AZURE_API_KEY", "4r6kDTdeYDaIynNTOtFEutxsgSHnC38kQTaNkUQ1d9PF1WlCxG1JJQQJ99BHACNns7RXJ3w3AAAAACOGTS8E")  # replace with your actual key for testing

# Construct the full endpoint URL dynamically
AZURE_ENDPOINT = f"{AZURE_BASE}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"

# -----------------------------
# Function to generate lesson
# -----------------------------
def generate_lesson(prompt, max_tokens=400, provider="azure"):
    """
    Generate a lesson using Azure Phi-4-mini-instruct.
    prompt: string - instructions for lesson
    max_tokens: int - max length of AI response
    provider: "azure" (Phi-4-mini-instruct)
    returns: string - lesson text
    """
    if provider != "azure":
        raise RuntimeError("Only Azure Phi-4-mini-instruct is supported in this setup")

    if not AZURE_ENDPOINT or not AZURE_API_KEY:
        raise RuntimeError("Azure endpoint or API key not configured")

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY
    }

    body = {
        "messages": [
            {"role": "system", "content": "You are an AI tutor generator. Produce structured lesson JSON and textual explanation."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": max_tokens,
        "temperature": 0.7
    }

    try:
        resp = requests.post(AZURE_ENDPOINT, headers=headers, json=body, timeout=30)
        resp.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Azure API request failed: {str(e)}")

    data = resp.json()
    
    # Extract content from choices
    choices = data.get("choices", [])
    if not choices:
        raise RuntimeError(f"No response from Azure: {data}")
    
    lesson_text = choices[0].get("message", {}).get("content", "")
    if not lesson_text:
        raise RuntimeError(f"No lesson content returned: {data}")

    return lesson_text
