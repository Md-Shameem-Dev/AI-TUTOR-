# app3.py
import os
import json
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, g
from flask_migrate import Migrate
from flask_cors import CORS

from models import db, User, Profile, Progress, Gamification, SpacedItem
import detection
import ai_client
import utils
from utils import create_token, decode_token, hash_password, verify_password

import requests

# ------------------ Flask setup ------------------
app = Flask(__name__)
CORS(app)  # Allow all origins for testing
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///ai_tutor.db")
app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)
migrate = Migrate(app, db)

# ------------------ Azure AI config ------------------
AZURE_BASE = "https://kaalan007010-5667-resource.services.ai.azure.com"
DEPLOYMENT_NAME = "Phi-4-mini-instruct"
API_VERSION = "2024-05-01-preview"
AZURE_API_KEY ="4r6kDTdeYDaIynNTOtFEutxsgSHnC38kQTaNkUQ1d9PF1WlCxG1JJQQJ99BHACNns7RXJ3w3AAAAACOGTS8E"  # set this in your env

# ------------------ Helpers ------------------
def auth_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing token"}), 401
        token = auth.split(" ", 1)[1]
        user_id = decode_token(token)
        if not user_id:
            return jsonify({"error": "Invalid token"}), 401
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        g.user = user
        return fn(*args, **kwargs)
    return wrapper

# ------------------ Routes ------------------

@app.route("/")
def index():
    return app.send_static_file("index3.html")  # put index3.html in /static

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})

# ------------------ Auth ------------------
@app.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    email = data.get("email")
    if not username or not password:
        return jsonify({"error": "username and password required"}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"error": "username exists"}), 400
    user = User(username=username, password_hash=hash_password(password), email=email)
    db.session.add(user)
    db.session.commit()
    profile = Profile(user_id=user.id, learning_style="unknown", interests="")
    gam = Gamification(user_id=user.id)
    db.session.add(profile)
    db.session.add(gam)
    db.session.commit()
    return jsonify({"message": "registered", "user_id": user.id})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username")
    password = data.get("password")
    if not username or not password:
        return jsonify({"error": "username and password required"}), 400
    user = User.query.filter_by(username=username).first()
    if not user or not verify_password(password, user.password_hash):
        return jsonify({"error": "invalid credentials"}), 401
    token = create_token(user.id)
    return jsonify({"token": token, "user_id": user.id})

# ------------------ Initial Learning Style Quiz ------------------
@app.route("/quiz/initial", methods=["POST"])
@auth_required
def initial_quiz():
    payload = request.get_json() or {}
    answers = payload.get("answers", {})
    res = detection.initial_quiz(answers)
    profile = g.user.profile
    profile.learning_style = res["style"]
    profile.detection_confidence = res["confidence"]
    db.session.commit()
    return jsonify({"style": res["style"], "confidence": res["confidence"]})

# ------------------ AI Test / Quiz ------------------
@app.route('/start-test', methods=['POST'])
@auth_required
def start_test():
    data = request.json
    topic = data.get("topic")
    num_questions = data.get("num_questions", 10)

    prompt = f"""
Generate {num_questions} multiple-choice questions on {topic}.
Each question should have 4 options labeled exactly as strings in an array,
and indicate the correct answer. Return the result as JSON only,
like:
[{{"question":"...","options":["Option A text","Option B text","Option C text","Option D text"],"answer":"Option A text"}}, ...]
Do not include any extra explanation.
"""

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY
    }
    payload = {
        "messages": [
            {"role": "system", "content": "You are an AI tutor. Return only valid JSON."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0,
        "max_tokens": 1000
    }

    url = f"{AZURE_BASE}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"

    try:
        resp = requests.post(url, headers=headers, json=payload)
        resp.raise_for_status()
        ai_text = resp.json()["choices"][0]["message"]["content"]

        # convert AI string to JSON
        questions = json.loads(ai_text)
        return jsonify({"questions": questions})

    except json.JSONDecodeError:
        # fallback placeholder
        questions = [{"question": f"Sample question {i+1}", "options":["Option A","Option B","Option C","Option D"], "answer":"Option A"} for i in range(num_questions)]
        return jsonify({"questions": questions, "warning": "AI output not valid JSON, using placeholders"})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ------------------ Update behavior metrics ------------------
@app.route("/behavior/update", methods=["POST"])
@auth_required
def update_behavior():
    payload = request.get_json() or {}
    behavior = payload.get("behavior", {})
    profile = g.user.profile
    old_style = profile.learning_style
    res = detection.update_style_with_behavior(old_style, behavior)
    profile.learning_style = res["style"]
    profile.detection_confidence = res["confidence"]
    db.session.commit()
    return jsonify({"style": res["style"], "confidence": res["confidence"]})

# ------------------ Lesson generation ------------------
@app.route("/lesson/generate", methods=["POST"])
@auth_required
def generate_lesson():
    payload = request.get_json() or {}
    topic = payload.get("topic")
    length = payload.get("length", "short")
    difficulty = payload.get("difficulty", "beginner")
    profile = g.user.profile
    style = profile.learning_style or "general"
    interests = profile.interests or ""
    provider = payload.get("provider", "azure")

    if not topic:
        return jsonify({"error": "topic required"}), 400

    prompt = (
        f"Create a lesson on '{topic}' for a {style} learner. "
        f"Difficulty: {difficulty}. Length: {length}. "
        "- A short learning objective\n"
        "- 3 activities tailored to the learner style (one interactive)\n"
        "- A short quiz with answers\n"
        "- Suggestions for spaced repetition items and summary\n"
    )
    if interests:
        prompt += f"\nUse examples related to: {interests}."

    try:
        lesson_text = ai_client.generate_lesson(prompt, provider=provider)
    except Exception as e:
        return jsonify({"error": "AI generation failed", "details": str(e)}), 500

    progress = Progress(user_id=g.user.id, lesson_id=f"{topic}-{datetime.utcnow().timestamp()}", status="in_progress")
    db.session.add(progress)
    db.session.commit()
    g.user.gamification.points += 5
    db.session.commit()

    return jsonify({"lesson": lesson_text, "progress_id": progress.id, "awarded_points": 5})

# ------------------ Report progress ------------------
@app.route("/progress/report", methods=["POST"])
@auth_required
def report_progress():
    payload = request.get_json() or {}
    progress_id = payload.get("progress_id")
    status = payload.get("status", "complete")
    accuracy = payload.get("accuracy", 0.0)
    time_spent = payload.get("time_spent_seconds", 0)
    behavior = payload.get("behavior", {})

    progress = Progress.query.get(progress_id)
    if not progress or progress.user_id != g.user.id:
        return jsonify({"error": "progress not found"}), 404

    progress.status = status
    progress.accuracy = accuracy
    progress.time_spent_seconds = time_spent
    progress.last_interaction = datetime.utcnow()
    db.session.commit()

    # Update spaced repetition items
    spaced = payload.get("spaced_items", [])
    for item in spaced:
        si = SpacedItem.query.filter_by(user_id=g.user.id, content_id=item['content_id']).first()
        if not si:
            si = SpacedItem(user_id=g.user.id, content_id=item['content_id'], interval_days=1,
                            repetition=0, easiness=2.5, last_reviewed=datetime.utcnow(),
                            due_date=datetime.utcnow())
            db.session.add(si)
        from utils import update_sm2
        local = {"repetition": si.repetition, "easiness": si.easiness, "interval_days": si.interval_days}
        updated = update_sm2(local, item.get("quality", 5))
        si.repetition = updated['repetition']
        si.easiness = updated['easiness']
        si.interval_days = updated['interval_days']
        si.last_reviewed = datetime.utcnow()
        si.due_date = datetime.utcnow() + timedelta(days=si.interval_days)

    det = detection.update_style_with_behavior(g.user.profile.learning_style, behavior)
    profile = g.user.profile
    profile.learning_style = det["style"]
    profile.detection_confidence = det["confidence"]

    gam = g.user.gamification
    if status == "complete" and accuracy >= 0.7:
        gam.points += int(10 * accuracy)
        gam.streak += 1
    else:
        gam.streak = 0
    db.session.commit()

    return jsonify({"message": "progress saved", "new_style": profile.learning_style,
                    "gamification": {"points": gam.points, "streak": gam.streak}})

# ------------------ Spaced repetition ------------------
@app.route("/spaced/due", methods=["GET"])
@auth_required
def spaced_due():
    now = datetime.utcnow()
    items = SpacedItem.query.filter(SpacedItem.user_id==g.user.id, SpacedItem.due_date <= now).all()
    out = [{"content_id": i.content_id, "due_date": i.due_date.isoformat(), "repetition": i.repetition} for i in items]
    return jsonify({"due": out})

# ------------------ Gamification ------------------
@app.route("/gamification", methods=["GET"])
@auth_required
def get_gamification():
    gam = g.user.gamification
    return jsonify({"points": gam.points, "streak": gam.streak, "badges": gam.badges.split(",") if gam.badges else []})

# ------------------ Community ------------------
@app.route("/community/match", methods=["GET"])
@auth_required
def community_match():
    profile = g.user.profile
    style = profile.learning_style or "unknown"
    matches = []
    if style != "unknown":
        q = Profile.query.filter(Profile.learning_style == style).join(User).limit(20).all()
        matches = [{"user_id": p.user_id, "username": p.user.username, "confidence": p.detection_confidence} for p in q if p.user_id != g.user.id]
    return jsonify({"matches": matches[:10]})

# ------------------ Admin ------------------
@app.route("/admin/users/<int:user_id>", methods=["GET"])
def admin_user(user_id):
    u = User.query.get(user_id)
    if not u:
        return jsonify({"error": "not found"}), 404
    return jsonify({
        "id": u.id, "username": u.username, "email": u.email,
        "learning_style": u.profile.learning_style if u.profile else None
    })

# ------------------ AI Chatbot ------------------
@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        user_message = data.get("message", "").strip()
        style = data.get("style", "general")
        if not user_message:
            return jsonify({"reply": "Please enter a message."})

        headers = {
            "Content-Type": "application/json",
            "api-key": AZURE_API_KEY
        }
        payload = {
            "messages": [
                {"role": "system", "content": f"You are an AI tutor. Tailor your explanation for a {style} learner."},
                {"role": "user", "content": user_message}
            ],
            "temperature": 0.7,
            "max_tokens": 500
        }

        url = f"{AZURE_BASE}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        ai_reply = response.json()["choices"][0]["message"]["content"]
        return jsonify({"reply": ai_reply})
    except Exception as e:
        return jsonify({"reply": f"Error: {str(e)}"})

# ------------------ Run server ------------------
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=int(os.getenv("PORT","5000")))
