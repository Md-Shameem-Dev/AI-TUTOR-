from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

# =========================
# Azure Phi-4-Mini-Instruct settings
# =========================
AZURE_ENDPOINT = "https://kaalan007010-5667-resource.services.ai.azure.com/models/chat/completions?api-version=2024-05-01-preview"  # Full invoke URL from Azure AI Studio
AZURE_API_KEY = "4r6kDTdeYDaIynNTOtFEutxsgSHnC38kQTaNkUQ1d9PF1WlCxG1JJQQJ99BHACNns7RXJ3w3AAAAACOGTS8E"   # Your Azure API key

# =========================
# Routes
# =========================
@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "status": "Server is running",
        "message": "Use POST /chat with JSON {question, style} to interact with AI."
    })


@app.route("/chat", methods=["POST"])
def chat():
    # Parse incoming data
    data = request.get_json(force=True)
    question = data.get("question", "").strip()
    style = data.get("style", "general").strip()

    if not question:
        return jsonify({"answer": "Please provide a question."}), 400

    # Check Azure settings
    if not AZURE_ENDPOINT or not AZURE_API_KEY:
        return jsonify({"answer": "Azure endpoint or API key is missing in app.py"}), 500

    # Azure API request
    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY
    }
    payload = {
        "messages": [
            {
                "role": "system",
                "content": f"You are an AI tutor. Tailor your explanation for a {style} learner."
            },
            {
                "role": "user",
                "content": question
            }
        ],
        "max_tokens": 300,
        "temperature": 0.7
    }

    try:
        response = requests.post(AZURE_ENDPOINT, headers=headers, json=payload, timeout=15)
        response.raise_for_status()
        result = response.json()
        
        # Extract AI answer
        answer = result.get("choices", [{}])[0].get("message", {}).get("content", "No answer from model.")
        return jsonify({"answer": answer})

    except requests.exceptions.RequestException as e:
        return jsonify({"answer": f"Error contacting Azure: {str(e)}"})
    except Exception as e:
        return jsonify({"answer": f"Unexpected error: {str(e)}"})


if __name__ == "__main__":
    app.run(debug=True)
