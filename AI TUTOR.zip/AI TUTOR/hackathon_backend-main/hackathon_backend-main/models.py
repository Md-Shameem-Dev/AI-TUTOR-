# models.py
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Association tables if needed later
# user_interests = db.Table(...)

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    profile = db.relationship("Profile", uselist=False, back_populates="user")
    progress = db.relationship("Progress", back_populates="user")
    gamification = db.relationship("Gamification", uselist=False, back_populates="user")

class Profile(db.Model):
    __tablename__ = "profiles"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True)
    # learning style: visual, auditory, kinesthetic, reading, blended, unknown
    learning_style = db.Column(db.String(32), default="unknown")
    interests = db.Column(db.String(512), default="")  # comma separated for simplicity
    detection_confidence = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="profile")

class Progress(db.Model):
    __tablename__ = "progress"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    lesson_id = db.Column(db.String(128))
    status = db.Column(db.String(32), default="pending")  # pending, complete, in_progress, failed
    accuracy = db.Column(db.Float, default=0.0)
    time_spent_seconds = db.Column(db.Integer, default=0)
    last_interaction = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="progress")

class SpacedItem(db.Model):
    __tablename__ = "spaced_items"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    content_id = db.Column(db.String(128))
    interval_days = db.Column(db.Integer, default=1)
    repetition = db.Column(db.Integer, default=0)
    easiness = db.Column(db.Float, default=2.5)
    due_date = db.Column(db.DateTime)
    last_reviewed = db.Column(db.DateTime)

class Gamification(db.Model):
    __tablename__ = "gamification"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True)
    points = db.Column(db.Integer, default=0)
    streak = db.Column(db.Integer, default=0)
    badges = db.Column(db.String(512), default="")  # comma separated

    user = db.relationship("User", back_populates="gamification")
