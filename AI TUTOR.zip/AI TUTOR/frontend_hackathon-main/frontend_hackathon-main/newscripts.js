const API_BASE = "http://127.0.0.1:5000";
let token = null;

// Generic API fetch
async function apiFetch(path, options = {}) {
  if (!options.headers) options.headers = {};
  if (token) options.headers["Authorization"] = "Bearer " + token;
  if (!options.headers["Content-Type"] && !(options.body instanceof FormData)) {
    options.headers["Content-Type"] = "application/json";
  }
  const res = await fetch(API_BASE + path, options);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// Navigation
document.getElementById("nav-auth").addEventListener("click", () => showSection("auth-section"));
document.getElementById("nav-quiz").addEventListener("click", () => showSection("quiz-section"));
document.getElementById("nav-lesson").addEventListener("click", () => showSection("lesson-section"));
document.getElementById("nav-gamification").addEventListener("click", () => showSection("gamification-section"));
document.getElementById("nav-chatbot").addEventListener("click", () => {
  window.location.href = "/chat.html";
});

function showSection(id) {
  document.querySelectorAll("main section").forEach(sec => sec.style.display = "none");
  document.getElementById(id).style.display = "block";
}

// Auth
document.getElementById("register-btn").addEventListener("click", async () => {
  try {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const email = document.getElementById("email").value.trim();
    await apiFetch("/register", {
      method: "POST",
      body: JSON.stringify({ username, password, email })
    });
    alert("Registered! Now log in.");
  } catch (e) {
    alert(e.message);
  }
});

document.getElementById("login-btn").addEventListener("click", async () => {
  try {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const data = await apiFetch("/login", {
      method: "POST",
      body: JSON.stringify({ username, password })
    });
    token = data.token;
    // persist so chat.html can read it
    localStorage.setItem("ai_tutor_token", token);
    alert("Logged in!");
    showSection("lesson-section");
    document.getElementById("quiz-section").style.display = "block";
    document.getElementById("gamification-section").style.display = "block";
  } catch (e) {
    alert(e.message);
  }
});

// Quiz
document.getElementById("quiz-submit-btn").addEventListener("click", async () => {
  try {
    const q1 = document.getElementById("q1").value;
    const data = await apiFetch("/quiz/initial", {
      method: "POST",
      body: JSON.stringify({ answers: { q1 } })
    });
    alert(`Detected style: ${data.style} (confidence ${Math.round(data.confidence * 100)}%)`);
  } catch (e) {
    alert(e.message);
  }
});

// Lesson display helper
function displayLesson(text) {
  const outputDiv = document.getElementById("lesson-output");
  let html = text
    .replace(/^#{1,6}\s*/gim, '')
    .replace(/\*\*(.*?)\*\*/gim, '<b>$1</b>')
    .replace(/^\s*[-*]\s+(.*)/gim, '<li>$1</li>')
    .replace(/(<li>.*<\/li>)/gims, '<ul>$1</ul>');
  outputDiv.innerHTML = html.trim();
}

// Lesson generation
document.getElementById("lesson-generate-btn").addEventListener("click", async () => {
  try {
    const topic = document.getElementById("topic").value.trim();
    const difficulty = document.getElementById("difficulty").value;
    const length = document.getElementById("length").value;
    const data = await apiFetch("/lesson/generate", {
      method: "POST",
      body: JSON.stringify({ topic, difficulty, length })
    });
    displayLesson(data.lesson);
    document.getElementById("read-lesson-btn").style.display = "inline-block";
  } catch (e) {
    alert(e.message);
  }
});

// TTS (Text-to-Speech)
document.getElementById("read-lesson-btn").addEventListener("click", () => {
  const textContent = document.getElementById("lesson-output").innerText.trim();
  if (!textContent) {
    alert("No lesson text to read.");
    return;
  }
  const utterance = new SpeechSynthesisUtterance(textContent);
  utterance.lang = "en-US";
  speechSynthesis.cancel();
  speechSynthesis.speak(utterance);
});

// Gamification
document.getElementById("refresh-gamification-btn").addEventListener("click", async () => {
  try {
    const data = await apiFetch("/gamification", { method: "GET" });
    document.getElementById("gamification-output").innerHTML =
      `<p><b>Points:</b> ${data.points}</p>
       <p><b>Streak:</b> ${data.streak}</p>
       <p><b>Badges:</b> ${data.badges.join(", ")}</p>`;
  } catch (e) {
    alert(e.message);
  }
});
