let learningStyle = "";

// Handle quiz button clicks
document.querySelectorAll(".quiz-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        learningStyle = btn.dataset.style;
        document.getElementById("quiz-section").style.display = "none";
        document.getElementById("chat-section").style.display = "block";
        addMessage("bot", `Got it! You are a ${learningStyle} learner. Let's start your lesson!`);
    });
});

// Handle chat send
document.getElementById("send-btn").addEventListener("click", sendMessage);
document.getElementById("user-input").addEventListener("keypress", e => {
    if (e.key === "Enter") sendMessage();
});

function sendMessage() {
    const input = document.getElementById("user-input");
    const text = input.value.trim();
    if (!text) return;
    addMessage("user", text);
    input.value = "";

    // Call backend (Azure Phi-4-Mini-Instruct) here
    fetch("http://127.0.0.1:5000/chat", { // Replace with your Flask endpoint
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: text, style: learningStyle })
    })
    .then(res => res.json())
    .then(data => {
        addMessage("bot", data.answer);
    })
    .catch(err => {
        addMessage("bot", "Error connecting to AI tutor.");
        console.error(err);
    });
}

function addMessage(sender, text) {
    const box = document.getElementById("chat-box");
    const msg = document.createElement("div");
    msg.classList.add(sender === "user" ? "user-msg" : "bot-msg");
    msg.textContent = (sender === "user" ? "You: " : "Tutor: ") + text;
    box.appendChild(msg);
    box.scrollTop = box.scrollHeight;
}
