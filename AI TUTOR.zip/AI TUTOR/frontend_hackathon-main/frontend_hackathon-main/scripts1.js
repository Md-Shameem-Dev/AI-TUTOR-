// --- Your existing code above this ---

document.getElementById("login-btn").addEventListener("click", async () => {
  try {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const data = await apiFetch("/login", {
      method: "POST",
      body: JSON.stringify({ username, password })
    });
    token = data.token;

    // Save token for later use (chat requests)
    try { localStorage.setItem("token", token); } catch (e) {}

    alert("Logged in!");
    showSection("lesson-section");
    document.getElementById("quiz-section").style.display = "block";
    document.getElementById("gamification-section").style.display = "block";
  } catch (e) {
    alert(e.message);
  }
});

// ====================
// AI Chatbot feature
// ====================

// Elements
const chatInput = document.getElementById("chat-input");     // Textbox for student
const sendBtn = document.getElementById("send-btn");         // Button to send
const chatBox = document.getElementById("chat-box");         // Chat message area

async function sendMessage() {
  const question = chatInput.value.trim();
  if (!question) return;

  // Show the user's message in chat
  appendMessage("You", question);
  chatInput.value = "";

  try {
    const res = await fetch("/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${localStorage.getItem("token") || ""}`
      },
      body: JSON.stringify({
        message: question
      })
    });

    const data = await res.json();

    if (data.error) {
      appendMessage("Bot", `Error: ${data.error}`);
    } else if (data.reply) {
      appendMessage("Bot", data.reply);
    } else {
      appendMessage("Bot", "Sorry, I couldn't understand that.");
    }
  } catch (err) {
    appendMessage("Bot", `Request failed: ${err.message}`);
  }
}

function appendMessage(sender, text) {
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message");
  msgDiv.innerHTML = `<strong>${sender}:</strong> ${text}`;
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll
}

// Event listener for send button
if (sendBtn) {
  sendBtn.addEventListener("click", sendMessage);
}

// Optional: send on Enter key
if (chatInput) {
  chatInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendMessage();
    }
  });
}

// --- Your existing code below this ---


