# app.py
import os
from datetime import datetime
from flask import Flask, request, jsonify, g, send_from_directory
from flask_migrate import Migrate
from flask_cors import CORS

from models import db, User, Profile, Progress, Gamification, SpacedItem
import detection
import ai_client
import utils
from utils import create_token, decode_token, hash_password, verify_password

# -------- Initialize Flask --------
app = Flask(__name__, static_folder="static")  # ensure static folder set
CORS(app)  # allow all origins by default

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///ai_tutor.db")
app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)
migrate = Migrate(app, db)

# -------- Serve frontend --------
@app.route("/")
def index():
    # Try index3.html first, else index.html
    static_dir = app.static_folder or "static"
    for name in ("index3.html", "index.html"):
        path = os.path.join(static_dir, name)
        if os.path.exists(path):
            return send_from_directory(static_dir, name)
    return "No index file found (expected index3.html or index.html in /static)", 404


# -------- Auth decorator ----------
def auth_required(fn):
    from functools import wraps

    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing token"}), 401
        token = auth.split(" ", 1)[1]
        user_id = decode_token(token)
        if not user_id:
            return jsonify({"error": "Invalid token"}), 401
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        g.user = user
        return fn(*args, **kwargs)

    return wrapper


# -------- Health check ----------
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": datetime.utcnow().isoformat()})


# -------- AI Chatbot endpoint ----------
@app.route("/chat", methods=["POST"])
@auth_required
def chat():
    """
    Handles chatbot questions from the student.
    Request JSON:
      {
        "message": "student question",      # required
        "subject": "math / physics ...",    # optional
        "history": [                         # optional chat history
          {"role":"user","content":"..."},
          {"role":"assistant","content":"..."}
        ]
      }
    """
    data = request.get_json(force=True, silent=True) or {}
    message = (data.get("message") or "").strip()
    subject = (data.get("subject") or "").strip()
    history = data.get("history") or []

    if not message:
        return jsonify({"error": "message is required"}), 400

    system_prompt = (
        "You are a helpful, friendly AI tutor. "
        "Explain step-by-step in short paragraphs, adapt to the student's level, "
        "use tiny examples for math/code when helpful, and end with a brief suggested next step."
    )

    messages = [{"role": "system", "content": system_prompt}]

    if subject:
        messages.append({"role": "system", "content": f"Subject context: {subject}"})

    # include prior conversation if provided
    for turn in history:
        if (
            isinstance(turn, dict)
            and turn.get("role") in ("user", "assistant")
            and isinstance(turn.get("content"), str)
        ):
            messages.append({"role": turn["role"], "content": turn["content"]})

    # latest user question
    messages.append({"role": "user", "content": message})

    try:
        reply = ai_client.chat_reply(messages=messages, max_tokens=500, temperature=0.4)
        # ✅ Change key to "answer" so frontend can read it directly
        return jsonify({"answer": reply})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# -------- Existing endpoints remain unchanged --------


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=int(os.getenv("PORT", "5000")))

 