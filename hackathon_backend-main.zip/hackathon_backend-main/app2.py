from flask import Flask, request, jsonify
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)  # This will allow all origins by default

# =========================
# Azure Phi-4-Mini-Instruct settings
# =========================
AZURE_BASE = "https://kaalan007010-5667-resource.services.ai.azure.com"
DEPLOYMENT_NAME = "Phi-4-mini-instruct"
API_VERSION = "2024-05-01-preview"

AZURE_API_KEY = "4r6kDTdeYDaIynNTOtFEutxsgSHnC38kQTaNkUQ1d9PF1WlCxG1JJQQJ99BHACNns7RXJ3w3AAAAACOGTS8E"  # Replace with your real API key

@app.route("/", methods=["GET"])
def home():
    return "Flask server is running! Use POST /chat to talk to the AI."

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    question = data.get("question", "")
    style = data.get("style", "general")

    if not question:
        return jsonify({"answer": "Please provide a question."}), 400

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY
    }
    payload = {
        "messages": [
            {
                "role": "system",
                "content": f"You are an AI tutor. Tailor your explanation for a {style} learner."
            },
            {
                "role": "user",
                "content": question
            }
        ],
        "max_tokens": 300,
        "temperature": 0.7
    }

    try:
        url = f"{AZURE_BASE}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()
        answer = result["choices"][0]["message"]["content"]
        return jsonify({"answer": answer})
    except Exception as e:
        return jsonify({"answer": f"Error: {str(e)}"})

if __name__ == "__main__":
    app.run(debug=True)

# =========================
# Azure Phi-4-Mini-Instruct chatbot endpoint
# =========================
AZURE_BASE = "https://kaalan007010-5667-resource.services.ai.azure.com"
DEPLOYMENT_NAME = "Phi-4-mini-instruct"
API_VERSION = "2024-05-01-preview"
AZURE_API_KEY = "YOUR_API_KEY_HERE"

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    question = data.get("question", "")
    style = data.get("style", "general")

    if not question:
        return jsonify({"answer": "Please provide a question."}), 400

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_API_KEY
    }
    payload = {
        "messages": [
            {
                "role": "system",
                "content": f"You are an AI tutor. Tailor your explanation for a {style} learner."
            },
            {
                "role": "user",
                "content": question
            }
        ],
        "max_tokens": 300,
        "temperature": 0.7
    }

    try:
        url = f"{AZURE_BASE}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()
        answer = result["choices"][0]["message"]["content"]
        return jsonify({"answer": answer})
    except Exception as e:
        return jsonify({"answer": f"Error: {str(e)}"})
